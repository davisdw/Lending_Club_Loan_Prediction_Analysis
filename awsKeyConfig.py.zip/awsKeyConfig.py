# aws Key Data Info
keyID = "AKIAQQWQW367U3ZQF6S4"
secretKey = "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"
encryptionKeyARN = "arn:aws:kms:us-east-2:035871186879:key/eaac9d69-4e8c-4661-90d2-f033349f69ea"
